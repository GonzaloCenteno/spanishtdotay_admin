

<?php $__env->startSection('content'); ?>

<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
    <div class="card">
        <h5 class="card-header">CREAR BLOG</h5>
        <form id="FormularioCrearBlog" method="POST" action="<?php echo e(route('blog.store')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
            <div class="card-body">
                <div class="form-row">
                    <div class="col-4">
                        <div class="form-group">
                            <label for="titulo" class="col-form-label">*Categoria:</label>
                            <select class="form-control" name="idcategoriablog">
                                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($categoria->idcategoriablog); ?>"><?php echo e($categoria->nombre); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <!-- <span class="invalid-feedback" role="alert" id="error_titulo"><strong></strong></span> -->
                        </div>
                    </div>
                    <div class="col-8">
    	                <div class="form-group">
    	                    <label for="titulo" class="col-form-label">*Titulo:</label>
    	                    <input id="titulo" type="text" class="form-control" name="titulo">
                            <span class="invalid-feedback" role="alert" id="error_titulo"><strong></strong></span>
    	                </div>
    	            </div>
                    <div class="col-8">
                        <div class="form-group">
                            <label for="subtitulo" class="col-form-label">*Subtitulo:</label>
                            <input id="subtitulo" type="text" class="form-control" name="subtitulo">
                            <span class="invalid-feedback" role="alert" id="error_subtitulo"><strong></strong></span>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="form-group">
                            <label for="imagen" class="col-form-label">*Imagen Principal:</label>
                            <input id="imagen" type="file" class="form-control" name="imagen">
                            <span class="invalid-feedback" role="alert" id="error_imagen"><strong></strong></span>
                        </div>
                    </div>
                    <div class="col-1 align-self-center text-center">
                        <div class="form-group">
                            <label class="custom-control custom-checkbox custom-control-inline">
                                <input type="checkbox" checked="" name="estado" class="custom-control-input"><span class="custom-control-label">¿Publicar?</span>
                            </label>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="form-group">
                            <input type="hidden" id="token" value="<?php echo e(csrf_token()); ?>">
                            <label for="contenido" class="col-form-label">*Contenido:</label>
                            <textarea id="contenido" name="contenido"></textarea>
                            <span class="invalid-feedback" role="alert" id="error_contenido"><strong></strong></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-footer">
                <button type="submit" id="guardar_data" class="btn btn-outline-primary btn-sm"><i class="fa fa-save"></i> Guardar</button>
                <a href="<?php echo e(route('blog.index')); ?>" class="btn btn-outline-danger btn-sm">Cancelar</a>
            </div>
        </form>
    </div>
</div>

<?php $__env->startSection('page-js-script'); ?>
<script type="text/javascript">

    $("#nombre").on('change keyup', function () {
        limpiarErrores($(this).attr('id'));
    });

    $('#FormularioCrearBlog').submit(function(e){
        e.preventDefault();
        $.ajax({
            headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
            url: $(this).attr('action'),
            type: 'POST',
            dataType: 'json',
            data: new FormData($(this)[0]),
            processData: false,
            contentType: false,
            // beforeSend:function()
            // {            
            //     MensajeDialogLoadAjax('FormularioCrearBlog', '...:: Cargando ::...');
            // },
            success: function (data) 
            {
                console.log(data);
                // MensajeDialogLoadAjaxFinish('FormularioCrearBlog');
                // mensajes_sistema(1);
            },
            error: function(error) {
                if (error.status == 422) {
                    // mensajes_sistema(4);
                    var data = error.responseJSON.errors;
                    for(let i in data){
                        mostrarErrores(i,data[i][0]);
                    }
                    // MensajeDialogLoadAjaxFinish('FormularioCrearBlog');
                }
                else {
                    // mensajes_sistema(3);
                    // MensajeDialogLoadAjaxFinish('FormularioCrearBlog');
                    console.log('error');
                    console.log(error);
                }
            }
        });
    });
</script>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-admin\resources\views/blog/create.blade.php ENDPATH**/ ?>