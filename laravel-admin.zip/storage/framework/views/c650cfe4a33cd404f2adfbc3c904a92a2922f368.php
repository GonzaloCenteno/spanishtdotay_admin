
<?php $__env->startSection('title', 'Administracion Cuestionario'); ?> 
<?php $__env->startSection('content'); ?>

<div class="col-12">
    <div class="card">
        <div class="col-12 text-left pt-2">
            <a href="<?php echo e(route('cuestionarios.create')); ?>" type="button" class="btn btn-outline-primary"><i class="fa fa-plus-circle fa-2x"></i> </a>
        </div>
        <div class="card-body">
            <div class="col-12">         
                <div class="form-group" id="contenedor">
	                <table id="tabla_cuestionario"></table>
	                <div id="paginador_tabla_cuestionario"></div>                         
	            </div>                                
            </div>
        </div>
    </div>
</div>

<?php $__env->startSection('page-js-script'); ?>
<script type="text/javascript">
    $(document).ready(function(){
        $("#cuestionarios").addClass("active");

        jQuery("#tabla_cuestionario").jqGrid({
            url: 'cuestionarios/1',
            datatype: 'json', mtype: 'GET',
            height: '400px', autowidth: true,
            toolbarfilter: true,
            forceFit:true,  
            colNames: ['#','NOMBRE','ASIGNAR'],
            rowNum: 20, sortname: 'id_cuestionario', sortorder: 'desc', viewrecords: true, caption: 'LISTADO DE CUESTIONARIOS', align: "center",
            colModel: [
                {name: 'id_cuestionario', index: 'id_cuestionario', align: 'center',width: 5},
                {name: 'nombre', index: 'nombre', align: 'left', width: 60},
                {name: 'btn_asignar', index: 'btn_asignar', align: 'left', width: 10, sortable:false},
            ],
            pager: '#paginador_tabla_cuestionario',
            rowList: [20, 30, 40, 50],
            gridComplete: function () {
                var idarray = jQuery('#tabla_cuestionario').jqGrid('getDataIDs');
                if (idarray.length > 0) {
                var firstid = jQuery('#tabla_cuestionario').jqGrid('getDataIDs')[0];
                        $("#tabla_cuestionario").setSelection(firstid);    
                    }
            },
            onSelectRow: function (Id){},
            ondblClickRow: function (Id){
                let url = "<?php echo e(route('cuestionarios.edit', 'id')); ?>";
                url = url.replace('id', Id);
                window.location.href = url;
            }
        });

        $(window).on('resize.jqGrid', function () {
            $("#tabla_cuestionario").jqGrid('setGridWidth', $("#contenedor").width());
        });

    });
</script>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-admin\resources\views/cuestionario/index.blade.php ENDPATH**/ ?>