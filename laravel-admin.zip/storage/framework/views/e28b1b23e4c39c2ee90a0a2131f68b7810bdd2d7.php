

<?php $__env->startSection('content'); ?>

<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
    <div class="card">
        <h5 class="card-header">BLOG</h5>
        <div class="card-body">
            <a href="<?php echo e(route('blog.create')); ?>" type="button" class="btn btn-outline-info"><i class="fa fa-plus-circle fa-2x"></i> </a>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-admin\resources\views/blog/index.blade.php ENDPATH**/ ?>