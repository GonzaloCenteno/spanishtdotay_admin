

<?php $__env->startSection('content'); ?>

<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
    <div class="card">
        <h5 class="card-header">CREAR RESPUESTAS</h5>
        <form id="FormularioCrearRespuesta" method="POST" action="<?php echo e(route('respuestas.store')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
            <div class="card-body">
                <div class="form-row">
                    <div class="col-12">
    	                <div class="form-group">
    	                    <label for="respuesta" class="col-form-label">*Respuesta:</label>
    	                    <input id="respuesta" type="text" class="form-control" name="respuesta" autocomplete="off">
                            <span class="invalid-feedback" role="alert" id="error_respuesta"><strong></strong></span>
    	                </div>
    	            </div>
                    <div class="col-8">
                        <div class="form-group">
                            <label for="id_pregunta" class="col-form-label">*Pregunta:</label>
                            <select id="id_pregunta" name="id_pregunta" class="form-control">
                                <?php $__currentLoopData = $pregunta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($pre->id_pregunta); ?>"><?php echo e($pre->pregunta); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <span class="invalid-feedback" role="alert" id="error_id_pregunta"><strong></strong></span>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-group">
                            <label for="estado" class="col-form-label">*Estado:</label>
                            <select id="estado" name="estado" class="form-control">
                                <option value="1">CORRECTA</option>  
                                <option value="2">INCORRECTA</option>  
                            </select>
                            <span class="invalid-feedback" role="alert" id="error_estado"><strong></strong></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-footer">
                <button type="submit" class="btn btn-outline-primary btn-sm"><i class="fa fa-save"></i> Guardar</button>
                <a href="<?php echo e(route('respuestas.index')); ?>" class="btn btn-outline-danger btn-sm">Cancelar</a>
            </div>
        </form>
    </div>
</div>

<?php $__env->startSection('page-js-script'); ?>
<script type="text/javascript">

    $("#respuestas").addClass("active");
    $("#respuesta").focus();

    $("#respuesta, #idpregunta, #estado").on('change keyup', function () {
        limpiarErrores($(this).attr('id'));
    });

    $('#FormularioCrearRespuesta').submit(function(e){
        e.preventDefault();
        $.ajax({
            headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
            url: $(this).attr('action'),
            type: 'POST',
            dataType: 'json',
            data: new FormData($(this)[0]),
            processData: false,
            contentType: false,
            beforeSend:function()
            {            
                alertas(1);
            },
            success: function (data) 
            {
                alertas(2,'respuestas');
            },
            error: function(error) {
                if (error.status == 422) {
                    alertas(3);
                    var data = error.responseJSON.errors;
                    for(let i in data){
                        mostrarErrores(i,data[i][0]);
                    }
                }
                else {
                    alertas(4);
                }
            }
        });
    });
</script>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-admin\resources\views/respuesta/create.blade.php ENDPATH**/ ?>