<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Models\Cuestionario;
use App\Http\Requests\CuestionarioRequest;
use Carbon\Carbon;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class CuestionarioController extends Controller
{
    public function index()
    {
        return view('cuestionario.index');
    }

    public function create()
    {
        return view('cuestionario/create');
    }

    public function edit($id)
    {
        return view('cuestionario.edit', [
            'cuestionario' => Cuestionario::where('id_cuestionario',$id)->first()
        ]);
    }

    public function show(Request $request,$id)
    {
        $page = $request['page'];
        $limit = $request['rows'];
        $sidx = $request['sidx'];
        $sord = $request['sord'];
        $start = ($limit * $page) - $limit; 
        if ($start < 0) {
            $start = 0;
        }
        $totalg = Cuestionario::count();
        $sql = Cuestionario::orderBY($sidx,$sord)->limit($limit)->offset($start)->get();

        $total_pages = 0;
        if (!$sidx) {
            $sidx = 1;
        }
        $count = $totalg;
        if ($count > 0) {
            $total_pages = ceil($count / $limit);
        }
        if ($page > $total_pages) {
            $page = $total_pages;
        }
        $Lista = new \stdClass();
        $Lista->page = $page;
        $Lista->total = $total_pages;
        $Lista->records = $count;
        foreach ($sql as $Index => $Datos) {
            $Lista->rows[$Index]['id'] = $Datos->id_cuestionario;
            $Lista->rows[$Index]['cell'] = array(
                $Datos->id_cuestionario,
                $Datos->nombre,
                '<a type="button" href="'.route('cuestionario_pregunta.edit',$Datos->id_cuestionario).'" class="btn btn-outline-secondary btn-xs btn-block"><i class="fa fa-edit fa-2x"></a>'
            );
        }
        return response()->json($Lista);
    }

    public function store(CuestionarioRequest $request)
    {
        if(!$request->ajax()) return redirect('/');
        return Cuestionario::create([
            'nombre' => $request['nombre'],
            'resumen' => $request['resumen'],
            'imagen' => $this->agregar_imagen($request->file('imagen')), 
            'descripcion'=> $request['descripcion']
        ]);
    }

    public function update(CuestionarioRequest $request, $id)
    {
        if(!$request->ajax()) return redirect('/');
        $cuestionario = Cuestionario::find($id);
        $imagen = $this->agregar_imagen($request->file('imagen'));
        if($imagen)
        {
            $cuestionario->update([
                'nombre' => $request['nombre'],
                'resumen' => $request['resumen'],
                'imagen' => $imagen, 
                'descripcion'=> $request['descripcion']
            ]);
        }
        else
        {
            $cuestionario->update([
                'nombre' => $request['nombre'],
                'resumen' => $request['resumen'],
                'descripcion'=> $request['descripcion']
            ]);
        }
        return $cuestionario->id_cuestionario;
    } 

    private function agregar_imagen($imagen){
        if($imagen)
        {
            $bandera = Str::random(12);
            $filename = $imagen->getClientOriginalName();
            $fileserver = $bandera.'_'.$filename;
            $imagen->move(public_path('images/blog/gramatica/'), htmlentities($fileserver));
            return 'images/blog/gramatica/'.$fileserver;
        }
        else
        {
            return false;
        }
    }
}
